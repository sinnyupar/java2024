package no1;
import java.util.Scanner;
public class No3 {
	 public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		 System.out.print("원가동의 밑면 반지름은? ");
		 int x = in.nextInt();
		 System.out.print("원가동의 높이는? ");
		 int y = in.nextInt();
		 int volume = (int) (x * x * y * 3.14) ;
		 System.out.println("원기동의 부파는"+ volume);
		 
	 }
}

